pact=['tell','show','know','what','whats','do','work']
nact=['no',"don't","not",'never',"shouldn't","won't","can't","doesn't","couldn't","wouldn't"]
weird=['don','shouldn','won','can','doesn','couldn','wouldn']
not_sure=['probably','maybe','might']
