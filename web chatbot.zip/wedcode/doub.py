doubl=['needs industry','need industry','cut off','rank jee']
doublr={
    'needs industry':'fbfg','need industry':'fbfg','cut off':'right','rank jee':'uuuuuu'
        }
doubwords=['needs','need','industry','cut','off','rank','jee']
