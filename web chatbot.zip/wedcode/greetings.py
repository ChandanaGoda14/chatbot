greet={'hi':'hello',
       'hii':'hello',
       'hiii':'hello',
        'hello':'hi',
        'hey':'hi'}
